const express = require('express');
const path = require('path');
const app = express();
const publicpath = path.join(__dirname, 'Public');
const reqFilter = require('./middleware.js'); // Import middleware file

const route = express.Router(); // Correct way to create a router

// Apply the middleware to specific routes using the router
route.use(reqFilter);

app.get('/', reqFilter, (req, resp) => {
    resp.sendFile(`${publicpath}/index.html`); // Single level middleware
});

route.get('/about', (req, resp) => {
    resp.sendFile(`${publicpath}/about.html`);
});

route.get('/contact', (req, resp) => {
    resp.sendFile(`${publicpath}/contact.html`);
});

app.get('/help', (_, resp) => {
    resp.sendFile(`${publicpath}/help.html`);
});

// Use the router for grouped routes
app.use('/', route);

app.listen(2000, () => {
    console.log('Server is running on http://localhost:2000');
});


const http= require('http');
const fs =require('fs');
const input =process.argv;

if(input[2] == 'add'){
    fs.writeFileSync(input[3],input[4]);  // for creating new file and adding text

}else if(input[2] == 'remove'){
    fs.unlinkSync(input[3]);  // for deleting file
}else{
    console.log('wrong input');
}


http.createServer(function(req,resp){
    resp.writeHead(200,{'Content-Type':'text/html'});
    resp.write('<h1>Hello world!</h1>');
    resp.end();
}).listen(3000);


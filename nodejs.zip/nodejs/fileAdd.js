const fs= require('fs');
const path=require('path'); // for putting file in a perticular folder
const dirPath=path.join(__dirname,'files');
// for(i=0;i<5;i++){
// fs.writeFileSync(dirPath+"/hello"+i+".txt","this is sample");  // for creating file using loop
// }
fs.readdir(dirPath,(err,filesshow)=>{
    console.log(filesshow) // show files in array form
    filesshow.forEach((item)=>{
        console.log(item) // show files in list form or not in array
    })
});

// curd with file systme below
const dirPathNew=path.join(__dirname,'Curd');
const filePath=`${dirPathNew}/apple.txt`;
//create file
// fs.writeFileSync(filePath,"this is the simple text for file apple.txt");
//read file
fs.readFile(filePath,'UTF8',(err,item)=>{ // reading the file
    console.log(item);
})


// update file
// fs.appendFile(filePath,' and apple is red colour',(err)=>{
//     if(!err) console.log("file is updated");
// });

//Rename file
// fs.rename(filePath,`${dirPathNew}/fruit.txt`,(err)=>{
//     if(!err) console.log("file rename success");
// })

// delte files
// fs.unlinkSync(`${dirPathNew}/fruit.txt`);


// // interview quesiton
// // what is Buffer 
// buffer mean a tempaory memory location which the node js need to perfor their operarion

// node js is single treaded
// node js is Asynchornous = multiple task can run symultensoly or without waiting others 

// drowbacks of node js 
// as it is asyncronous lang but it has drow back  for example below

// let a=10;
// let b=0;
// setTimeout(()=>{
//     b=20;
// },2000)
// console.log(a+b);


//  here above we have two variable with the givne values now we are consoling it because of asycronous behaviour the output would be 10 but the real time output should be 30 but 
//  its running asyncronouscally so it unable to update the value this is drowback of nodes js so this kind of situation can be handle by (promises or callback 



// Handle Asyncornous behaviours using promises(latest) start
// let a=10;
// let b=0;

// let waitingData= new Promise((resolve,reject)=>{
//     setTimeout(()=>{
//         resolve(10);
//     },2000)

// })

// waitingData.then((data)=>{
//     b=data;
//     console.log(a+b);
// })

// Handle Asyncornous behaviours using promises(latest) end
// NOte: filter function has already promises so that why we can us directly like filter.then()
// mostly we use promises when we make out custom function



// HOw NOde js works
// points: Call Stack  = its register our function before execute it handles which function run first and so on , so the main function register first and then other and also goes at last when all the function executed
// Node Apis  = as you know that node js is written in c, c++ and 92% in javascript but the function like setTimeout is c++ function so the function which is a part of c and c++ will come/registered here not in Call Stack
// here we call it node api because you know that api mean application programming  interface(mean the realationship bewteen two programming so the node js and c++ is two promming here as setTimeout is c++ funciton) 
// CallBack Queqe = after executing from Node api the function will come in CallBack queqe and then go to the Call Stack and show the result
// Example start
console.log("i will finish first because go in Call Stack and then show result");
setTimeout(()=>{
    console.log("i will finish last as  i am from c++ so will go in node api then CallBack queqe and then in Call Stack and then will show result");
},2000);
setTimeout(()=>{
    console.log('i will com third last as i am also from c++ so will go in node api then CallBack queqe and then in Call Stack and then will show result');
},0);

console.log("i will come second bec go in Call Stack and then show result");
// Example ends
// interview question
// HOw NOde js works or what is archtechture of node js?


//Express Js ?
// Express Js is the framework of node js, it give us middlewhere, easily can make api, routes, easily request handling
// install express
// Make Example with express js
// interview question
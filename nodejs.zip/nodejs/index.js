const express= require('express');
const path=require('path');
const app=express();
const publicpath=path.join(__dirname,'Public');

// app.use(express.static(publicpath))  // use is express js function 
app.get('/',(_,resp)=>{
    resp.sendFile(`${publicpath}/index.html`);
})

app.get('/about',(_,resp)=>{
    resp.sendFile(`${publicpath}/about.html`)
})

app.get('/help',(_,resp)=>{
    resp.sendFile(`${publicpath}/help.html`)
});

app.set('view engine', 'ejs');
app.get('/Dynamicpage',(_,resp)=>{
    const user={
        name:"umesh",
        email:"umesh@test.com",
        phone:"73747373727",
        city:"banglore",
        skills:['php','html','node','express','java']
    }
    resp.render('Dynamicpage',{user});
    
});

app.get('/login',(_,resp) =>{
    resp.render('login');
})

app.get('*',(_,resp)=>{
    resp.sendFile(`${publicpath}/404.html`)
});

app.listen(3000);


// question 

// what is path method do?
// it help to access the folder 

// what is static method do?
// it help to access the static page or content

// we can not us css or images directly bec our path come from node js


// how to remove extension ?
// how to load file using get file method
// answer is with the help of sentFile method
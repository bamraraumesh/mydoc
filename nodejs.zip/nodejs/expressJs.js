//Express Js ?
// Express Js is the framework of node js, it give us middlewhere, easily can make api, routes, easily request handling
// install express
// Make Example with express js
// interview question


const express= require('express');
const app=express();
app.get('',(req,res)=>{
    res.send(` "Welcome to home page"
    <a href="/arguments">Goto arguments page</a>
    `);
});
app.get('/about',(req,res)=>{  // how to make simple  routes
    res.send('hello , this is about page');
});
app.get('/help',(req,res)=>{  // how to get json data
    res.send([
        { name:'umesh',
        email:'umesh@gmail.com'
       },
       { name:'sanjay',
        email:'sanjay@gmail.com',
        phone:7283949392
       },
    ]);
});
app.get('/arguments/',(req,res)=>{
   
    // res.send("my name is ==> " +req.query.name);
    // below is how to put html  links and how to pass arguments
    res.send(`
    <input type="text"  placeholder="user name" value="${req.query.name}" />     
    <button type="button">click me</button>
    <span style="color:red">${req.query.name}</span>

    <a href="/">Goto homepage</a>
    `);
});

app.listen(3000);